/* HTTP surface for the Coach — user routes and admin routes.
 *
 * Written as a factory taking server.js's own helpers rather than importing them: the helpers
 * are closures over the db and the session secret, and passing them in keeps this module free
 * of a cycle (and trivially testable against fakes).
 */
import * as cfgStore from './config.js';
import * as oauth from './oauth.js';
import * as jobs from './jobs.js';
import { adapterFor } from './adapters/index.js';
import { DATA_CATEGORIES } from './payload.js';

// Job failures the user sees, in the app's own voice. The raw provider detail never reaches
// them — it goes to the admin card, which is where someone can act on it (FR-47).
const USER_ERROR = {
  off: 'the Coach is not set up on this instance',
  busy: 'the Coach is already thinking about your training',
  cap: 'the Coach is resting — try again tomorrow',
  consent: 'the Coach needs your go-ahead first'
};
const HTTP_FOR = { off: 503, busy: 409, cap: 429, consent: 403 };

export function coachRoutes({ json, readBody, readSession, requireAdmin }) {
  /** Every user route starts the same way: signed in, feature on, feature reachable. */
  const guard = (req, res) => {
    const user = readSession(req);
    if (!user) { json(res, 401, { error: 'not signed in' }); return null; }
    if (!cfgStore.isEnabled() || !cfgStore.isConnected()) { json(res, 503, { error: USER_ERROR.off }); return null; }
    return user;
  };
  const failEnqueue = (res, e) => {
    if (e instanceof jobs.CoachError) return json(res, HTTP_FOR[e.code] || 400, { error: USER_ERROR[e.code] || e.message, code: e.code });
    throw e;
  };

  return {
    /* ------------------------------ user ------------------------------ */

    // What the consent screen has to disclose, straight from the module that builds payloads,
    // so the screen cannot drift from what actually leaves (FR-09).
    'GET /api/coach/disclosure': async (req, res) => {
      const cfg = cfgStore.load();
      json(res, 200, {
        provider: cfg.provider,
        providerLabel: cfgStore.providerMeta(cfg).label,
        categories: DATA_CATEGORIES,
        version: 1
      });
    },

    'GET /api/coach/status': async (req, res) => {
      const user = guard(req, res); if (!user) return;
      json(res, 200, jobs.status(user.id));
    },

    'POST /api/coach/plan': async (req, res) => {
      const user = guard(req, res); if (!user) return;
      const body = await readBody(req);
      try {
        const job = jobs.enqueue(user.id, {
          kind: 'create',
          intake: body.intake || null,
          refine: body.refine ? String(body.refine).slice(0, 1000) : null
        });
        json(res, 202, { job });
      } catch (e) { failEnqueue(res, e); }
    },

    'POST /api/coach/review': async (req, res) => {
      const user = guard(req, res); if (!user) return;
      const body = await readBody(req);
      try {
        const job = jobs.enqueue(user.id, { kind: 'review', note: body.note ? String(body.note).slice(0, 1000) : null });
        json(res, 202, { job });
      } catch (e) { failEnqueue(res, e); }
    },

    'POST /api/coach/pending/resolve': async (req, res) => {
      const user = guard(req, res); if (!user) return;
      const body = await readBody(req);
      json(res, 200, jobs.resolvePending(user.id, {
        accepted: Array.isArray(body.accepted) ? body.accepted : [],
        rejected: Array.isArray(body.rejected) ? body.rejected : [],
        dismissed: !!body.dismissed
      }));
    },

    // Consent withdrawn, or the profile turned the Coach off: drop everything held server-side
    // for them at once, without waiting for a sync to carry the news (D5).
    'POST /api/coach/forget': async (req, res) => {
      const user = readSession(req);
      if (!user) return json(res, 401, { error: 'not signed in' });
      jobs.clearUser(user.id);
      json(res, 200, { ok: true });
    },

    /* ------------------------------ admin ------------------------------ */

    'GET /api/admin/coach': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      const cfg = cfgStore.load();
      const adapter = adapterFor(cfg.provider);
      const check = adapter ? await adapter.check(cfg, cfgStore.jobEnv(process.env.TMPDIR || '/tmp')) : { ok: false, error: 'unknown provider' };
      const log = cfg.log || [];
      const today = new Date().toISOString().slice(0, 10);
      json(res, 200, {
        disabledByEnv: cfgStore.COACH_DISABLED,
        enabled: !!cfg.enabled,
        provider: cfg.provider,
        providers: Object.entries(cfgStore.PROVIDERS).map(([id, p]) => ({ id, label: p.label, runtime: p.runtime, setupToken: !!p.setupToken, deviceLogin: !!p.deviceLogin, apiKey: !!p.apiKeyEnv })),
        model: cfg.model,
        caps: cfg.caps,
        runtime: { ok: !!check.ok, version: check.version || null, error: check.error || null },
        auth: await oauth.liveAuthStatus(),
        // Counts and outcomes only — never intake answers, payloads or proposals (FR-12/A4).
        jobsToday: log.filter(e => (e.at || '').slice(0, 10) === today).length,
        lastSuccess: cfgStore.lastSuccess(),
        lastError: cfgStore.lastError(),
        recent: log.slice(-20).reverse().map(e => ({ at: e.at, kind: e.kind, trigger: e.trigger, outcome: e.outcome, errorClass: e.errorClass, ms: e.ms }))
      });
    },

    'POST /api/admin/coach/config': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      const body = await readBody(req);
      const patch = {};
      if (body.enabled !== undefined) patch.enabled = !!body.enabled;
      if (body.provider !== undefined) {
        if (!cfgStore.PROVIDERS[body.provider]) return json(res, 400, { error: 'unknown provider' });
        // Credentials belong to the provider that issued them.
        if (body.provider !== cfgStore.load().provider) patch.auth = null;
        patch.provider = body.provider;
      }
      if (body.model !== undefined) patch.model = body.model ? String(body.model).slice(0, 80) : null;
      if (body.caps) {
        patch.caps = {
          perProfileDaily: Math.max(0, Math.min(200, +body.caps.perProfileDaily || 0)),
          instanceDaily: Math.max(0, Math.min(5000, +body.caps.instanceDaily || 0))
        };
      }
      cfgStore.save(patch);
      json(res, 200, { ok: true });
    },

    'POST /api/admin/coach/test': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      const r = await jobs.testRun();
      json(res, 200, r);
    },

    'POST /api/admin/coach/auth/setup-token': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      const body = await readBody(req);
      try {
        oauth.setSetupToken(body.token);
        const test = await jobs.testRun();
        json(res, 200, { ok: true, test });
      } catch (e) { json(res, 400, { error: e.message }); }
    },

    // Codex itself performs the ChatGPT device-code authorization. This server only starts the
    // local CLI, relays the short-lived instructions to the signed-in admin, and later checks
    // whether Codex created its own private auth cache.
    'POST /api/admin/coach/auth/chatgpt/device': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      const body = await readBody(req);
      try { json(res, 200, oauth.startCodexDeviceLogin({ replace: !!body.replace })); }
      catch (e) { json(res, 400, { error: e.message }); }
    },

    'GET /api/admin/coach/auth/chatgpt/status': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      json(res, 200, oauth.codexDeviceLoginStatus());
    },

    'POST /api/admin/coach/auth/key': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      const body = await readBody(req);
      try {
        oauth.setApiKey(body.key);
        const test = await jobs.testRun();
        json(res, 200, { ok: true, test });
      } catch (e) { json(res, 400, { error: e.message }); }
    },

    'POST /api/admin/coach/auth/disconnect': async (req, res) => {
      if (!requireAdmin(req, res)) return;
      try {
        await oauth.disconnect();
        json(res, 200, { ok: true });
      } catch (e) { json(res, 400, { error: e.message }); }
    }
  };
}
